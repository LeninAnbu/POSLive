class UserValues {
  static String username = '';
  static int userID = 0;
  static String userCode = '';

  static String terminal = '';
  static String userType = '';
  static String userStaus = '';
  static String licenseKey = '';
  static String? branch = '';
  static String? salesExce = '';
  static String? deviceID = '';
  static String? lastUpdateIp = '';
}
