class PaidFrom{
  String? accountcode;
  String? accountname;
  String? balance;
  
  PaidFrom({
    required this.accountcode,
    required this.accountname,
    required this.balance,
    
  });
}