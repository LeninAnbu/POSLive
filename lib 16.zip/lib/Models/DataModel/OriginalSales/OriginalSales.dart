
class OrdinalSales {
  final String year;
  final double sales;

  OrdinalSales(this.year, this.sales);
}