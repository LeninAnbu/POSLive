// class StockOutLinelist {
//   String? docentry;
//   String? lineno;
//   int? itemcode;
//   String? description;
//   int? qty;
//   String? status;
//   String? baseDocentry;
//   String? baseDocline;
//   String? serialbatch;

//   StockOutLinelist(
//       {required this.lineno,
//       required this.docentry,
//       required this.itemcode,
//       required this.description,
//       required this.qty,
//       required this.baseDocentry,
//       required this.baseDocline,
//       required this.status,
//       required this.serialbatch});
// }