class codeforexpense{
 String expensecode;
  String expensename;
  String debit;
  String credit;
  String limit;
  codeforexpense({
    required this.expensecode,
    required this.expensename,
    required this.debit,
    required this.credit,
    required this.limit
  });
}