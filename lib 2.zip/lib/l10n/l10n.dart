


import 'package:flutter/cupertino.dart';

class L10n //"@@locale": "ar", "@@locale": "en",
{
  static final all = {
    const Locale("en"),
    const Locale("ar"),

  };
}