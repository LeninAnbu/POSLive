class AppConstant {
  static String branch = ''; //sessionID
  static String terminal = '';
  // static String sessionID = '';
  static String sapSessionID = '';
  static String version = '';
  static String ip = '';
  static String? sapDB = '';
  static String? slpCode = '';

  static String? sapUserName = '';
  static String? sapPassword = '';

  static String url = 'http://$ip:80/Api/';
}
