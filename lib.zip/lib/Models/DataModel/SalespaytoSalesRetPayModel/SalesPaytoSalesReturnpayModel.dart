
class SalesPaytoSalesRetModel {
  String? salesrcmode;
  double? salesrcamt;
  String? docentry;

  SalesPaytoSalesRetModel(
      {required this.salesrcmode,
      required this.salesrcamt,
      required this.docentry});
}
