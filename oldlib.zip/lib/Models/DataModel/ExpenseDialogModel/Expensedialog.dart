class Expensedummy{
 String? docentry;
  String? expensecode;
  String? reference;
  String? rcamount;
  String? paidto;
  String? paidfrom;
  String? docstatus;
Expensedummy({
   this.docentry,
  required this.expensecode,
  required this.reference,
  required this.rcamount,
  required this.paidto,
  required this.paidfrom,
  required this.docstatus
});

}