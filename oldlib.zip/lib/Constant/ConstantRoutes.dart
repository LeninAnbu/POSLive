class ConstantRoutes {
  static String dashboard = "/Dashboard";
  static String salesQuotation = "/SalesQuotation";
  static String sales = "/sales";
  static String salesReturn = "/salesReturn";
  static String paymentReciept = "/paymentReciept";
  static String stockRequest = "/stockRequest";
  static String stockInward = "/stockInward";
  static String stockOutward = "/stockOutward";
  static String expence = "/expence";
  static String reconciliation = "/reconciliation";

  static String deposits = "/deposits";
  static String newprofile = "/newprofile";
  static String salesOrder = "/salesOrder";
  static String stockCheck = "/stockCheck";
  static String stockReplenish = "/StockReplenish";
  static String downloadPage = "/DownloadPage";
  static String stockRegister = "/StockRegister";
  static String retrurnRegister = "/retrurnRegister";
  static String cashStatement = "/cashStatement";
  static String pendingOrders = "/pendingOrders";
  static String customer = "/customer";
  static String refunds = "/refunds";
  static String apiSettings = "/apiSettings";
  static String syncdataPage = "/syncdataPage";
  static String numberSeris = "/NumberSeries";
  static String showPdf = "/showPdf";
}
